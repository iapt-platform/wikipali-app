//package mmcalendar;

import org.junit.Test;

public class MyanmarDateTest {

	@Test
	public void checkObjectCreation(){
		
	}
}
