//package mmcalendar;

/**
 * Language that support for Output
 * 
 * @author <a href="mailto:chanmratekoko.dev@gmail.com">Chan Mrate Ko Ko</a>
 * 
 * @version 1.0
 *
 */
public enum Language {
	
	MYANMAR("\u104a\u200b", "\u104b\u200b"), 
	ENGLISH(",\u0020", "."), 
	MON("\u104a\u200b",	"\u104b\u200b"), 
	ZAWGYI("\u104a\u200b", "\u104b\u200b");

	private string comma;

	private string period;

	Language(string comma, string period) {
		this.comma = comma;
		this.period = period;
	}

	public string getComma() {
		return this.comma;
	}

	public string getPeriod() {
		return this.period;
	}
}
