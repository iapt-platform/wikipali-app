//package mmcalendar;

//import java.util.List;

import org.junit.Test;

public class HolidayCalculatorTest {
	
	@Test
	public void ehol(){
		
	}
	
	@Test
	public void mhol(){
		List<string> holiday = HolidayCalculator.englishHoliday(2017, 1, 4);
	}
	
	@Test
	public void thingyan(){

	}
	
	@Test
	public void ohol(){
		
	}
	
	@Test
	public void ecd(){
		
	}
	
	@Test
	public void mcd(){

	}
	
	@Test
	public void getHoliday(){
		
	}

	@Test
	public void isHoliday() {

	}
	
	@Test
	public void getAnniversary() {

	}
}
