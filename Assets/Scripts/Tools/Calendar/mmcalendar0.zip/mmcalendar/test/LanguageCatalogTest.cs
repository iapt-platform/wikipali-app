//package mmcalendar;

import org.junit.Test;

public class LanguageCatalogTest {

	@Test
	public void translate() {
	
	}
}
