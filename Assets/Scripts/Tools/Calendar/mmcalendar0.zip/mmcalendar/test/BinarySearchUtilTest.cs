//package mmcalendar;

import org.junit.Test;

public class BinarySearchUtilTest {

	@Test
	public void search2D(){
		
	}
	
	@Test
	public void search1D(){
		
	}
}
