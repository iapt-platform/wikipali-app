Graphics donated by [area55](https://github.com/area55git).
