## ENHANCEMENT REQUESTS

The following items are requests that are on hold until time & resources can be devoted to them. Other developers are free to undertake these enhancements as desired. 

* Add ENU from ECEF
* NMEA Sentences
* Planetary Calculations
