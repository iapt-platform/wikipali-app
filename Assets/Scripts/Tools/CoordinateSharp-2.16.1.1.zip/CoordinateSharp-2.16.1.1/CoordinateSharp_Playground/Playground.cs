﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoordinateSharp;
using CoordinateSharp.Formatters;
using CoordinateSharp.Magnetic;
using CoordinateSharp.Debuggers;
using System.IO;
using System.Timers;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.ComponentModel;
using System.Runtime.CompilerServices;
//using System.Windows.Forms;
namespace CoordinateSharp_Playground
{
    class Playground
    {    
        [STAThread]
        static void Main()
        {        
            Console.ReadKey();           
        }      
    } 
}
