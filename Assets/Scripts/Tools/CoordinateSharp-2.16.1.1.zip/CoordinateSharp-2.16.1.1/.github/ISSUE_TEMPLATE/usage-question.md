---
name: Usage Question
about: Ask questions on how to use CoordinateSharp
title: "[QUESTION]"
labels: question
assignees: ''

---

Tell us what your question is. Please include any code samples so that we can better assist you.
