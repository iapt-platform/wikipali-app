﻿using Imdork.SQLite;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class ArticleManager
{
    //懒汉式单例类.在第一次调用的时候实例化自己 
    private ArticleManager() { }
    private static ArticleManager manager = null;
    //静态工厂方法 
    public static ArticleManager Instance()
    {
        if (manager == null)
        {
            manager = new ArticleManager();
        }
        return manager;
    }
    public DBManager dbManager = DBManager.Instance();
    #region 读取Json目录树
    const string defualtJsonFilePath = "defualt";
    const string cscd4JsonFilePath = "cscd";

    /// <summary>
    /// 通过StreamReader读取本地StreamingAssets文件夹中的Json文件
    /// <param name="jsonName">json文件名或文件名路径</param>
    /// </summary>
    string ReadJsonFromStreamingAssetsPath(string jsonName)
    {
        TextAsset textAsset = Resources.Load<TextAsset>("Json/PalicanonCategory/" + jsonName);
        return textAsset.text;
    }
    public string ReadDefualtJson()
    {
        return ReadJsonFromStreamingAssetsPath(defualtJsonFilePath);
    }
    public string ReadCSCDJson()
    {
        return ReadJsonFromStreamingAssetsPath(cscd4JsonFilePath);
    }
    #endregion

    #region 读取数据库句子与释义
    public class BookDBData
    {
        public int id;
        public string toc;
        public int level;
        public int paragraph;//段落数
        public int parent;//是父的paragraph?
        //public string translateName;
    }
    /// <summary>
    /// 输入Tag，返回book数据
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public List<BookDBData> GetBooksFromTags(List<string> tag)
    {
        int length = tag.Count;
        List<BookDBData> bookList = new List<BookDBData>();
        if (tag == null || length == 0)
            return bookList;
        List<string> anchorIDList = new List<string>();
        dbManager.Getdb(db =>
        {
            for (int i = 0; i < length; i++)
            {
                List<string> tempList = new List<string>();

                //查找tagID
                var reader = db.SelectSame("tag", tag[i], "name", 1, "id");

                //调用SQLite工具  解析对应数据
                Dictionary<string, object>[] pairs = SQLiteTools.GetValues(reader);
                if (pairs != null)
                {
                    int pLength = pairs.Length;
                    for (int pi = 0; pi < pLength; pi++)
                    {
                        string tagID = pairs[pi]["id"].ToString();
                        var readerTag = db.SelectSame("tag_map", tagID, "tag_id", 20000, "anchor_id");
                        Dictionary<string, object>[] tagPairs = SQLiteTools.GetValues(readerTag);
                        if (tagPairs != null)
                        {

                            int tagLength = tagPairs.Length;
                            for (int t = 0; t < tagLength; t++)
                            {
                                //取所有tag获取到的结果的交集
                                string anchorID = tagPairs[t]["anchor_id"].ToString();
                                if (i == 0)
                                {
                                    tempList.Add(anchorID);
                                }
                                else
                                {
                                    if (anchorIDList.Contains(anchorID))
                                    {
                                        tempList.Add(anchorID);
                                    }
                                }


                            };
                        }
                    }
                }
                anchorIDList = tempList;
            }
            length = anchorIDList.Count;
            for (int i = 0; i < length; i++)
            {
                var readerPali = db.SelectSame("pali_text", anchorIDList[i], "id", 1, "book", "paragraph", "level", "toc", "chapter_len", "next_chapter", "prev_chapter", "parent");
                Dictionary<string, object>[] paliPairs = SQLiteTools.GetValues(readerPali);
                if (paliPairs == null)
                    continue;
                int paliLength = paliPairs.Length;
                for (int p = 0; p < paliLength; p++)
                {
                    BookDBData book = new BookDBData()
                    {
                        id = int.Parse(paliPairs[p]["book"].ToString()),
                        paragraph = int.Parse(paliPairs[p]["paragraph"].ToString()),
                        level = int.Parse(paliPairs[p]["level"].ToString()),
                        toc = paliPairs[p]["toc"].ToString(),
                        parent = int.Parse(paliPairs[p]["parent"].ToString()),
                    };
                    bookList.Add(book);
                }
            }

        }, DBManager.SentenceDBurl);
        return bookList;
    }
    #endregion
}
